import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "60"))

DEVS = list(map(int, os.getenv("DEVS", "2073740352").split()))

API_ID = int(os.getenv("API_ID", "28533577"))

API_HASH = os.getenv("API_HASH", "b023bead181e115bb99853be0698770c")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8087795642:AAHQ1luUjUbO3tITKEDS98t7gm263CqbTis")

OWNER_ID = int(os.getenv("OWNER_ID", "2073740352"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002684429171").split()))

RMBG_API = os.getenv("RMBG_API", "xBhRUmJih1BcgUWDJHhfxRaC")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://erzaraska4:erzaraska4@cluster0.hliznep.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "--1002684429171"))
